---
title: Introduction
type: docs
---

# Привет! 👋

Меня зовут Александра Матях и это мое тестовое задание на позицию технического писателя для [documentat.io](https://documentat.io/)

Здесь вы можете найти две инструкции по получению бесплатных SSL-сертификатов от **Let's Encrypt** для вашего сайта на **Apache** или **nginx**, обе на английском и русском языках.

Если у вас возникнут какие-либо вопросы, ко мне можно обратиться по e-mail [matyah.oleksandra@gmail.com](mailto:matyah.oleksandra@gmail.com)

Хорошего дня! 🙂